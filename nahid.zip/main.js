// Modal Functions
function openSignup() {
    document.getElementById('signupModal').style.display = 'block';
}

function closeSignup() {
    document.getElementById('signupModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('signupModal');
    if (event.target === modal) {
        closeSignup();
    }
}

// Form Handling
function handleSubmit(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Add your form submission logic here
    alert(`Thank you for signing up, ${username}! We've sent a confirmation to ${email}`);
    
    // Reset form
    document.getElementById('signupForm').reset();
    closeSignup();
}

// Scroll Animations
window.addEventListener('scroll', () => {
    const elements = document.querySelectorAll('.animate-on-scroll');
    elements.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        if (elementTop < window.innerHeight * 0.8) {
            element.classList.add('fadeInUp');
        }
    });
});
